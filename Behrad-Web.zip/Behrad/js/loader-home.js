let spinner = document.querySelector(".spinner");

spinner.forEach(setTimeout(() => {
    spinner.style.display = "none"
}, 3500))